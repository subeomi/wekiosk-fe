import ListComponent from "../../components/device/ListComponent";

const ListPage = () => {
    return (
        <div>
            <ListComponent></ListComponent>
        </div>
    );
}

export default ListPage;