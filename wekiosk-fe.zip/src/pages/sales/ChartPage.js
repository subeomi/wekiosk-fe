import ChartComponent from "../../components/sale/ChartComponent";


const ChartPage = () => {
  return (  
    <div className=" h-[570px]">
      <ChartComponent></ChartComponent>
    </div>
  );
}
 
export default ChartPage;