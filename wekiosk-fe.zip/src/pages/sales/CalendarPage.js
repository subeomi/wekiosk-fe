import CalendarComponent from "../../components/sale/CalendarComponent";


const CalendarPage = () => {
  return (
    <div className="h-[570px]">
      <CalendarComponent></CalendarComponent>
    </div>
  );
}

export default CalendarPage;