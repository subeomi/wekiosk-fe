import { Outlet } from "react-router-dom";


const ModifyIndexPage = () => {
    return (
        <div>
            <Outlet></Outlet>
        </div>
    );
}

export default ModifyIndexPage;