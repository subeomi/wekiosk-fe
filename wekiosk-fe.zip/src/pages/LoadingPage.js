const LoadingPage = () => {
    return (
        <div>
            Loading...
        </div>
    );
}

export default LoadingPage;